import{$ as w,e as n,a as g,s as k,b as x,t as S}from"./main-CNPx2KPJ.js";const A=5e3,M=40;function P(t){const a=t.querySelector("[data-banner-track]"),e=Array.from(t.querySelectorAll("[data-banner-slide]")),m=t.querySelector("[data-banner-dots]");if(a===null||e.length===0)return()=>{};const i=window.matchMedia("(prefers-reduced-motion: reduce)").matches;let o=0,f;const p=e.map((l,r)=>{const u=document.createElement("button");return u.type="button",u.className="banner__dot",u.setAttribute("role","tab"),u.setAttribute("aria-label",`第 ${r+1} 条`),u.addEventListener("click",()=>{s(r),b()}),u});m!==null&&e.length>1&&m.append(...p);const v=t.querySelector("[data-banner-prev]"),$=t.querySelector("[data-banner-next]");v?.addEventListener("click",()=>{s(o-1),b()}),$?.addEventListener("click",()=>{s(o+1),b()});function s(l){o=(l+e.length)%e.length,a.style.transform=`translateX(-${o*100}%)`,p.forEach((r,u)=>{r.classList.toggle("is-active",u===o),r.setAttribute("aria-selected",u===o?"true":"false")})}const c=()=>{window.clearInterval(f),f=void 0},h=()=>{i||e.length<2||document.hidden||(c(),f=window.setInterval(()=>s(o+1),A))},b=()=>{c(),h()};let d=!1,_=0;const L=l=>{d=!0,_=l.clientX,c()},q=l=>{if(!d)return;d=!1;const r=l.clientX-_;Math.abs(r)>M&&s(o+(r<0?1:-1)),b()},y=()=>{document.hidden?c():h()};t.addEventListener("pointerdown",L),t.addEventListener("pointerup",q),t.addEventListener("pointercancel",()=>{d=!1,b()});const E=l=>{const r=l.target instanceof Element?l.target.closest('a[href="#"]'):null;r!==null&&t.contains(r)&&l.preventDefault()};return t.addEventListener("click",E),t.addEventListener("mouseenter",c),t.addEventListener("mouseleave",h),t.addEventListener("focusin",c),t.addEventListener("focusout",h),document.addEventListener("visibilitychange",y),s(0),h(),()=>{c(),t.removeEventListener("click",E),document.removeEventListener("visibilitychange",y)}}function B(t){if(t.repost===null)return"";if(!t.repost.available||t.repost.author===null)return'<div class="repost-quote is-unavailable"><p class="repost-quote__missing">原动态已删除或不可见</p></div>';const a=t.repost.thumb!==""?`<img class="repost-quote__thumb" src="${n(t.repost.thumb)}" alt="" loading="lazy">`:"";return`<div class="repost-quote">
      <div class="repost-quote__head">
          <span class="material-symbols-outlined" aria-hidden="true">repeat</span>
          <a href="${n(t.repost.author.url)}">${n(t.repost.author.nickname)}</a>
      </div>
      <a class="repost-quote__body" href="${n(t.repost.url)}">
          <span class="repost-quote__text">${n(t.repost.excerpt)}</span>
          ${a}
      </a>
  </div>`}function C(t){if(t.media.length===0)return"";const a=t.media[0];if(a!==void 0&&a.kind==="video")return`<div class="post-media" data-count="1"><video class="post-media__video" controls preload="metadata" playsinline src="${n(a.url)}"></video></div>`;const e=t.media.slice(0,4),m=e.map(i=>`<button class="post-media__item" type="button" data-action="lightbox" data-src="${n(i.url)}"><img src="${n(i.thumb)}" alt="动态图片" loading="lazy"></button>`).join("");return`<div class="post-media" data-count="${e.length}">${m}</div>`}function H(t){return t.topics.length===0?"":`<div class="post-topics">${t.topics.map(e=>`<a class="topic-chip" href="${n(e.url)}">#${n(e.name)}</a>`).join("")}</div>`}function I(t){const a=document.createElement("template"),e=t.can_edit?`<a class="icon-btn icon-btn--sm" href="/posts/${t.id}" aria-label="查看动态" title="查看动态">
            <span class="material-symbols-outlined" aria-hidden="true">more_vert</span>
        </a>`:w.get()!==null?`<button class="icon-btn icon-btn--sm" type="button" data-action="report"
                data-target-type="post" data-target-id="${t.id}" aria-label="举报">
            <span class="material-symbols-outlined" aria-hidden="true">flag</span>
        </button>`:"";return a.innerHTML=`
<article class="card post-card" data-post-id="${t.id}" data-post-link="/posts/${t.id}">
    <header class="post-card__head">
        <span class="avatar avatar--md" style="--avatar-hue: ${t.author.hue}" aria-hidden="true">${n(t.author.initial)}</span>
        <div class="post-card__meta">
            <a class="post-card__author" href="${n(t.author.url)}">${n(t.author.nickname)}</a>
            <div class="post-card__sub">
                <time datetime="${n(t.created_at)}">${n(t.time_ago)}</time>
                ${t.is_repost?'<span class="meta-chip">转发</span>':""}
                ${t.visibility==="private"?'<span class="meta-chip">仅自己可见</span>':""}
                ${t.is_pinned?'<span class="meta-chip meta-chip--accent">置顶</span>':""}
            </div>
        </div>
        ${e}
    </header>
    <div class="post-card__body">
        ${t.content_text!==""?`<div class="post-content">${t.content_html}</div>`:""}
        ${B(t)}
        ${C(t)}
        ${H(t)}
    </div>
    <footer class="post-card__foot">
        <button class="post-action${t.liked?" is-active":""}" type="button"
                data-action="toggle-like" data-target-type="post" data-target-id="${t.id}"
                aria-pressed="${t.liked?"true":"false"}" aria-label="点赞">
            <span class="material-symbols-outlined" aria-hidden="true">favorite</span>
            <span class="post-action__count" data-like-count>${t.like_count}</span>
        </button>
        <a class="post-action" href="/posts/${t.id}#comments" aria-label="评论">
            <span class="material-symbols-outlined" aria-hidden="true">chat_bubble</span>
            <span class="post-action__count">${t.comment_count}</span>
        </a>
        <button class="post-action${t.favorited?" is-active":""}" type="button"
                data-action="toggle-favorite" data-target-type="post" data-target-id="${t.id}"
                aria-pressed="${t.favorited?"true":"false"}" aria-label="收藏">
            <span class="material-symbols-outlined" aria-hidden="true">bookmark</span>
        </button>
        <button class="post-action post-action--tail" type="button" data-action="share"
                data-share-url="/posts/${t.id}" aria-label="复制链接">
            <span class="material-symbols-outlined" aria-hidden="true">share</span>
        </button>
    </footer>
</article>`,a.content.firstElementChild}const R=()=>{const t=[],a=g("[data-banner]");a!==null&&t.push(P(a));const e=g("[data-feed]"),m=g("[data-feed-list]",e??document),i=g('[data-action="load-more"]',e??document);if(e===null||m===null||i===null)return()=>t.forEach(s=>s());const o=e.dataset.currentTab??"latest",f=e.dataset.feedEndpoint??"";let p=Number(i.dataset.nextPage??2),v=!1;const $=async()=>{if(!v){v=!0,k(i,!0);try{const s=f!==""?`${f}?page=${p}`:`/api/v1/feed?tab=${encodeURIComponent(o)}&page=${p}&per_page=10`,{data:c,meta:h}=await x.get(s);for(const d of c)m.append(I(d));p+=1;const b=h.pagination?.pages??p;if(p>b){i.setAttribute("hidden","");const d=i.parentElement?.querySelector("[data-load-more-hint]");d!=null&&(d.hidden=!1)}}catch(s){S(s)}finally{v=!1,k(i,!1)}}};return i.addEventListener("click",$),()=>{i.removeEventListener("click",$),t.forEach(s=>s())}};export{R as init};
