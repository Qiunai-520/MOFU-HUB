import{e as t,$ as u}from"./main-CNPx2KPJ.js";function _(a,n={}){const r=document.createElement("template"),i=n.isReply===!0,e=n.anonymous===!0,s=(e?a.author.display:a.author.nickname)??"",o=!e&&typeof a.author.avatar_url=="string"&&a.author.avatar_url!==""?`<img class="avatar avatar--sm" src="${t(a.author.avatar_url)}" alt="" loading="lazy">`:`<span class="avatar avatar--sm" style="--avatar-hue: ${a.author.hue}" aria-hidden="true">${t(a.author.initial)}</span>`,l=e?o:`<a class="avatar-link" href="${t(a.author.url??"")}" aria-label="${t(s)} 的主页">${o}</a>`,d=e?`<span class="comment__author comment-card__author--anon">${t(s)}</span>`:`<a class="comment__author" href="${t(a.author.url??"")}">${t(s)}</a>`,c=!e&&a.reply_to?`<span class="comment__reply-to">回复 ${t(a.reply_to.nickname)}</span>`:"";return r.innerHTML=`
<div class="comment${i?" comment--reply":""}" data-comment-id="${a.id}">
    ${l}
    <div class="comment__body">
        <div class="comment__head">
            ${d}
            ${c}
            <time class="comment__time" datetime="${t(a.created_at??"")}">${t(a.time_ago)}</time>
        </div>
        <div class="comment__content">${a.content_html}</div>
        <div class="comment__actions">
            <button class="post-action post-action--sm${a.liked?" is-active":""}" type="button"
                    data-action="toggle-like" data-target-type="${e?"confession_comment":"comment"}" data-target-id="${a.id}"
                    aria-pressed="${a.liked?"true":"false"}">
                <span class="material-symbols-outlined" aria-hidden="true">favorite</span>
                <span class="post-action__count" data-like-count>${a.like_count}</span>
            </button>
            ${u.get()!==null?`<button class="text-btn text-btn--sm" type="button" data-action="reply" data-comment-id="${a.id}" data-reply-name="${t(s)}">回复</button>`:""}
            ${a.can_remove?`<button class="text-btn text-btn--sm text-btn--danger" type="button" data-action="remove-comment" data-comment-id="${a.id}">删除</button>`:""}
        </div>
    </div>
</div>`,r.content.firstElementChild}export{_ as r};
