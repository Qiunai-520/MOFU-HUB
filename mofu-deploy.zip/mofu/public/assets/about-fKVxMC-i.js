const f="button, a[href]";function u(e,l){return l.trim()===""?"":`<div class="member-dialog__row">
      <span class="member-dialog__label">${e}</span>
      <span class="member-dialog__value" data-member-value></span>
  </div>`}function p(e){document.querySelector(".member-dialog")?.remove();const l=document.activeElement instanceof HTMLElement?document.activeElement:null,t=document.createElement("div");t.className="member-dialog",t.innerHTML=`
<div class="member-dialog__panel mofu-dialog__panel" role="dialog" aria-modal="true" aria-labelledby="member-dialog-name" tabindex="-1">
    <div class="member-dialog__head">
        <span class="member-dialog__avatar" data-member-avatar></span>
        <span>
            <span class="member-dialog__name" id="member-dialog-name" data-member-name></span>
            ${e.role.trim()===""?"":'<span class="member-dialog__role meta-chip meta-chip--accent" data-member-role></span>'}
        </span>
    </div>
    <div class="member-dialog__rows">
        ${u("邮箱",e.email)}
        ${u("加入时间",e.since)}
    </div>
    ${e.bio.trim()===""?"":'<p class="member-dialog__bio" data-member-bio></p>'}
    <div class="member-dialog__foot">
        <button class="filled-btn filled-btn--sm" type="button" data-member-close>知道了</button>
    </div>
</div>`,document.body.append(t);const n=t.querySelector(".member-dialog__panel"),m=t.querySelector("[data-member-avatar]"),s=t.querySelector("[data-member-name]");s!==null&&(s.textContent=e.name),t.querySelector("[data-member-role]")?.append(e.role),t.querySelector("[data-member-bio]")?.append(e.bio);const b=t.querySelectorAll("[data-member-value]"),v=[e.email,e.since];if(b.forEach((a,o)=>{a.textContent=v[o]??""}),m!==null)if(e.avatar!==""){const a=document.createElement("img");a.className="member-dialog__avatar",a.src=e.avatar,a.alt="",a.loading="lazy",m.replaceWith(a)}else m.textContent=e.name.slice(0,1);const i=()=>{document.removeEventListener("keydown",c),t.remove(),l?.focus()};t.addEventListener("click",a=>{const o=a.target;(o===t||o.closest("[data-member-close]")!==null)&&i()});const c=a=>{if(a.key==="Escape"){i();return}if(a.key!=="Tab"||n===null)return;const o=Array.from(n.querySelectorAll(f));if(o.length===0){a.preventDefault();return}const r=o[0],d=o[o.length-1]??r;r!==void 0&&(a.shiftKey&&document.activeElement===r?(a.preventDefault(),d?.focus()):!a.shiftKey&&document.activeElement===d&&(a.preventDefault(),r.focus()))};document.addEventListener("keydown",c),n?.focus()}const g=()=>{const e=l=>{const t=l.target;if(!(t instanceof Element))return;const n=t.closest("[data-team-member]");n!==null&&p({name:n.dataset.memberName??"",role:n.dataset.memberRole??"",bio:n.dataset.memberBio??"",avatar:n.dataset.memberAvatar??"",email:n.dataset.memberEmail??"",since:n.dataset.memberSince??""})};return document.addEventListener("click",e),()=>document.removeEventListener("click",e)};export{g as init};
