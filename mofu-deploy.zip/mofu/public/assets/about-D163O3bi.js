const v="button, a[href]";function p(a){return`<div class="member-dialog__row">
      <span class="member-dialog__label">${a}</span>
      <span class="member-dialog__value" data-member-value></span>
  </div>`}function g(a){document.querySelector(".member-dialog")?.remove();const r=document.activeElement instanceof HTMLElement?document.activeElement:null,t=document.createElement("div");t.className="member-dialog";const i=[["邮箱",a.email],["加入时间",a.since]].filter(([,e])=>e.trim()!=="");t.innerHTML=`
<div class="member-dialog__panel mofu-dialog__panel" role="dialog" aria-modal="true" aria-labelledby="member-dialog-name" tabindex="-1">
    <div class="member-dialog__head">
        <span class="member-dialog__avatar" data-member-avatar></span>
        <span>
            <span class="member-dialog__name" id="member-dialog-name" data-member-name></span>
            ${a.role.trim()===""?"":'<span class="member-dialog__role meta-chip meta-chip--accent" data-member-role></span>'}
        </span>
    </div>
    <div class="member-dialog__rows">
        ${i.map(([e])=>p(e)).join("")}
    </div>
    ${a.bio.trim()===""?"":'<p class="member-dialog__bio" data-member-bio></p>'}
    <div class="member-dialog__foot">
        <button class="filled-btn filled-btn--sm" type="button" data-member-close>知道了</button>
    </div>
</div>`,document.body.append(t);const m=t.querySelector(".member-dialog__panel"),s=t.querySelector("[data-member-avatar]"),c=t.querySelector("[data-member-name]");c!==null&&(c.textContent=a.name),t.querySelector("[data-member-role]")?.append(a.role),t.querySelector("[data-member-bio]")?.append(a.bio);const f=t.querySelectorAll("[data-member-value]");if(i.forEach(([,e],n)=>{const l=f[n];l!==void 0&&(l.textContent=e)}),s!==null)if(a.avatar!==""){const e=document.createElement("img");e.className="member-dialog__avatar",e.src=a.avatar,e.alt="",e.loading="lazy",s.replaceWith(e)}else s.textContent=a.name.slice(0,1);const d=()=>{document.removeEventListener("keydown",u),t.remove(),r?.focus()};t.addEventListener("click",e=>{const n=e.target;(n===t||n.closest("[data-member-close]")!==null)&&d()});const u=e=>{if(e.key==="Escape"){d();return}if(e.key!=="Tab"||m===null)return;const n=Array.from(m.querySelectorAll(v));if(n.length===0){e.preventDefault();return}const l=n[0],b=n[n.length-1]??l;l!==void 0&&(e.shiftKey&&document.activeElement===l?(e.preventDefault(),b?.focus()):!e.shiftKey&&document.activeElement===b&&(e.preventDefault(),l.focus()))};document.addEventListener("keydown",u),m?.focus()}const _=()=>{const a=r=>{const t=r.target;if(!(t instanceof Element))return;const o=t.closest("[data-team-member]");o!==null&&g({name:o.dataset.memberName??"",role:o.dataset.memberRole??"",bio:o.dataset.memberBio??"",avatar:o.dataset.memberAvatar??"",email:o.dataset.memberEmail??"",since:o.dataset.memberSince??""})};return document.addEventListener("click",a),()=>document.removeEventListener("click",a)};export{_ as init};
