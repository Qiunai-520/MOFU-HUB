import{$ as M,e as t,a as k,s as I,b as S,t as N}from"./main-a-EEhByv.js";const B=5e3,R=40,x=new Set;let A=!1;function T(){A||(A=!0,document.addEventListener("visibilitychange",()=>{for(const e of x)document.hidden?e.stop():e.start()}))}function C(e){if(e.dataset.bannerBound==="1")return()=>{};e.dataset.bannerBound="1";const a=e.querySelector("[data-banner-track]"),n=Array.from(e.querySelectorAll("[data-banner-slide]")),i=e.querySelector("[data-banner-dots]");if(a===null||n.length===0)return()=>{};const r=window.matchMedia("(prefers-reduced-motion: reduce)").matches;let o=0,y;const w=n.map((s,l)=>{const $=document.createElement("button");return $.type="button",$.className="banner__dot",$.setAttribute("role","tab"),$.setAttribute("aria-label",`第 ${l+1} 条`),$.addEventListener("click",()=>{v(l),f()}),$});i!==null&&n.length>1&&i.append(...w);const h=e.querySelector("[data-banner-prev]"),E=e.querySelector("[data-banner-next]");h?.addEventListener("click",()=>{v(o-1),f()}),E?.addEventListener("click",()=>{v(o+1),f()});function v(s){o=(s+n.length)%n.length,a.style.transform=`translateX(-${o*100}%)`,w.forEach((l,$)=>{l.classList.toggle("is-active",$===o),l.setAttribute("aria-selected",$===o?"true":"false")})}const p=()=>{window.clearInterval(y),y=void 0},b=()=>{r||n.length<2||document.hidden||(p(),y=window.setInterval(()=>{if(!e.isConnected){p(),x.delete(m);return}v(o+1)},B))},f=()=>{p(),b()};let g=!1,L=0;const u=s=>{g=!0,L=s.clientX,p()},d=s=>{if(!g)return;g=!1;const l=s.clientX-L;Math.abs(l)>R&&v(o+(l<0?1:-1)),f()},_=()=>{g=!1,f()};e.addEventListener("pointerdown",u),e.addEventListener("pointerup",d),e.addEventListener("pointercancel",_);const c=s=>{const l=s.target instanceof Element?s.target.closest('a[href="#"]'):null;l!==null&&e.contains(l)&&s.preventDefault()};e.addEventListener("click",c),e.addEventListener("mouseenter",p),e.addEventListener("mouseleave",b),e.addEventListener("focusin",p),e.addEventListener("focusout",b);const m={start:b,stop:p};return x.add(m),T(),v(0),b(),()=>{x.delete(m),p(),e.removeEventListener("pointerdown",u),e.removeEventListener("pointerup",d),e.removeEventListener("pointercancel",_),e.removeEventListener("click",c),e.removeEventListener("mouseenter",p),e.removeEventListener("mouseleave",b),e.removeEventListener("focusin",p),e.removeEventListener("focusout",b),delete e.dataset.bannerBound}}function j(e){if(e.repost===null)return"";if(!e.repost.available||e.repost.author===null)return'<div class="repost-quote is-unavailable"><p class="repost-quote__missing">原动态已删除或不可见</p></div>';const a=e.repost.thumb!==""?`<img class="repost-quote__thumb" src="${t(e.repost.thumb)}" alt="" loading="lazy">`:"";return`<div class="repost-quote">
      <div class="repost-quote__head">
          <span class="material-symbols-outlined" aria-hidden="true">repeat</span>
          <a href="${t(e.repost.author.url)}">${t(e.repost.author.nickname)}</a>
      </div>
      <a class="repost-quote__body" href="${t(e.repost.url)}">
          <span class="repost-quote__text">${t(e.repost.excerpt)}</span>
          ${a}
      </a>
  </div>`}function z(e){if(e.media.length===0)return"";const a=e.media.slice(0,3),n=a.map((i,r)=>{const o=r===a.length-1&&e.media.length>3;return i.kind==="video"?`<a class="post-preview-media__item post-preview-media__item--video" href="/posts/${e.id}" aria-label="进入帖子查看视频"><video preload="metadata" muted playsinline src="${t(i.url)}"></video><span class="post-preview-media__play material-symbols-outlined" aria-hidden="true">play_arrow</span><span class="post-preview-media__tag">视频</span></a>`:o?`<a class="post-preview-media__item post-preview-media__item--more" href="/posts/${e.id}" aria-label="查看全部 ${e.media.length} 张图片"><img src="${t(i.thumb)}" alt="" loading="lazy"><span class="post-preview-media__more">+${e.media.length-2}</span></a>`:`<button class="post-preview-media__item" type="button" data-action="lightbox" data-kind="image" data-src="${t(i.url)}" aria-label="预览图片"><img src="${t(i.thumb)}" alt="动态图片" loading="lazy"></button>`}).join("");return`<div class="post-preview-media" data-count="${a.length}" aria-label="动态媒体预览">${n}</div>`}function H(e){return e.author.name_badge_image?`<img class="name-badge name-badge--image" src="${t(e.author.name_badge_image)}" alt="">`:e.author.name_badge_emoji?`<span class="name-badge" title="${t(e.author.name_badge_label??"个人挂件")}">${t(e.author.name_badge_emoji)}</span>`:""}function D(e){const a=e.author,n=a.avatar_url?`<img class="avatar" src="${t(a.avatar_url)}" alt="" loading="lazy" decoding="async">`:`<span class="avatar" style="--avatar-hue: ${a.hue}" aria-hidden="true">${t(a.initial)}</span>`;return a.avatar_frame_class?`<span class="avatar-frame avatar-frame--md ${t(a.avatar_frame_class)}">${n}</span>`:a.avatar_url?`<img class="avatar avatar--md" src="${t(a.avatar_url)}" alt="" loading="lazy" decoding="async">`:`<span class="avatar avatar--md" style="--avatar-hue: ${a.hue}" aria-hidden="true">${t(a.initial)}</span>`}function X(e){return e.topics.length===0?"":`<div class="post-topics">${e.topics.map(n=>`<a class="topic-chip" href="${t(n.url)}">#${t(n.name)}</a>`).join("")}</div>`}function O(e){const a=e.tags??[];return a.length===0?"":`<div class="post-tags">${a.map(i=>{const r=i.color!==""?` style="--tag-color: ${t(i.color)}"`:"";return`<a class="tag-chip" href="${t(i.url)}"${r}>${t(i.name)}</a>`}).join("")}</div>`}function P(e){const a=document.createElement("template"),n=e.can_delete?`<button class="icon-btn icon-btn--sm" type="button" data-action="delete-post" data-post-id="${e.id}" aria-label="删除动态" title="删除动态">
            <span class="material-symbols-outlined" aria-hidden="true">delete</span>
        </button>`:e.can_edit?`<a class="icon-btn icon-btn--sm" href="/posts/${e.id}" aria-label="查看动态" title="查看动态">
            <span class="material-symbols-outlined" aria-hidden="true">more_vert</span>
        </a>`:M.get()!==null?`<button class="icon-btn icon-btn--sm" type="button" data-action="report"
                data-target-type="post" data-target-id="${e.id}" aria-label="举报">
            <span class="material-symbols-outlined" aria-hidden="true">flag</span>
        </button>`:"",i=e.author.is_formal?`<span class="level-chip${e.author.is_flash?" level-chip--flash":""}">${e.author.is_flash?'<span class="material-symbols-outlined" aria-hidden="true">bolt</span>':""}Lv.${e.author.level}</span>`:"",r=e.author.title,o=r!=null?`<span class="level-chip"><span class="material-symbols-outlined" aria-hidden="true">${t(r.icon)}</span>${t(r.name)}</span>`:"";return a.innerHTML=`
<article class="card post-card" data-post-id="${e.id}" data-post-link="/posts/${e.id}">
    <header class="post-card__head">
        ${D(e)}
        <div class="post-card__meta">
            <div class="post-card__title-row">
            <a class="post-card__author${e.author.is_premium?" is-premium":""}" href="${t(e.author.url)}">${t(e.author.nickname)}${H(e)}</a>
            ${i}
            ${o}
            </div>
            <div class="post-card__sub">
                <time datetime="${t(e.created_at)}">${t(e.time_ago)}</time>
                ${e.is_repost?'<span class="meta-chip">转发</span>':""}
                ${e.visibility==="private"?'<span class="meta-chip">仅自己可见</span>':""}
                ${e.is_pinned?'<span class="meta-chip meta-chip--accent">置顶</span>':""}
            </div>
        </div>
        ${n}
    </header>
    <div class="post-card__body">
        ${e.content_text!==""?`<div class="post-content" data-post-content>
            <div class="post-content__text" data-post-content-text>${e.content_html}</div>
            <a class="post-more" href="/posts/${e.id}" hidden>…查看更多</a>
        </div>`:""}
        ${e.is_paid===!0&&e.unlocked===!1?`<div class="paid-lock">
            <p class="paid-lock__excerpt">${t((e.excerpt??"").slice(0,60))}</p>
            <div class="paid-lock__foot">
                <span class="material-symbols-outlined" aria-hidden="true">lock</span>
                <span class="paid-lock__price">${e.price??0} M币</span>
                <button class="filled-btn filled-btn--sm" type="button" data-action="purchase-post" data-post-id="${e.id}">解锁查看</button>
            </div>
        </div>`:""}
        ${j(e)}
        ${X(e)}
        ${O(e)}
    </div>
    ${z(e)}
    <footer class="post-card__foot">
        <button class="post-action${e.liked?" is-active":""}" type="button"
                data-action="toggle-like" data-target-type="post" data-target-id="${e.id}"
                aria-pressed="${e.liked?"true":"false"}" aria-label="点赞">
            <span class="material-symbols-outlined" aria-hidden="true">favorite</span>
            <span class="post-action__count" data-like-count>${e.like_count}</span>
        </button>
        <a class="post-action" href="/posts/${e.id}#comments" aria-label="评论">
            <span class="material-symbols-outlined" aria-hidden="true">chat_bubble</span>
            <span class="post-action__count" data-twikoo-count data-comment-path="/posts/${e.id}">${e.comment_count}</span>
        </a>
        <button class="post-action${e.favorited?" is-active":""}" type="button"
                data-action="toggle-favorite" data-target-type="post" data-target-id="${e.id}"
                aria-pressed="${e.favorited?"true":"false"}" aria-label="收藏">
            <span class="material-symbols-outlined" aria-hidden="true">bookmark</span>
            <span class="post-action__count" data-favorite-count>${e.favorite_count??0}</span>
        </button>
        <button class="post-action post-action--tail" type="button" data-action="share"
                data-share-url="/posts/${e.id}" aria-label="复制链接">
            <span class="material-symbols-outlined" aria-hidden="true">share</span>
        </button>
    </footer>
</article>`,a.content.firstElementChild}const q=new Map,U="400px",F=()=>{const e=k("[data-banner]");e!==null&&C(e);const a=k("[data-feed]"),n=k("[data-feed-list]",a??document),i=k("[data-feed-sentinel]",a??document);if(a===null||n===null||i===null)return()=>{};const r=a.dataset.currentTab??"latest",o=a.dataset.feedEndpoint??"",y=Number(a.dataset.pages??1),w=Number(a.dataset.publishedId??0);let h=Number(a.dataset.nextPage??2),E=!1;w>0&&window.requestAnimationFrame(()=>{const u=n.querySelector(`[data-post-id="${w}"]`);u!==null&&(u.classList.add("is-new-post"),u.scrollIntoView({block:"center",behavior:window.matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth"}),window.setTimeout(()=>u.classList.remove("is-new-post"),2400));const d=new URL(window.location.href);d.searchParams.delete("published"),window.history.replaceState(window.history.state,"",d)});const v=q.get(r);v!==void 0&&(n.append(...v.nodes),h=v.nextPage);const p=()=>h>y,b=async()=>{if(E||p())return;E=!0;const u=I(n,2);try{const d=o!==""?`${o}?page=${h}`:`/api/v1/feed?tab=${encodeURIComponent(r)}&page=${h}&per_page=10`,{data:_}=await S.get(d),c=_.map(s=>P(s));for(const s of u)s.remove();n.append(...c),h+=1;const m=q.get(r)??{nextPage:h,nodes:[]};m.nodes.push(...c),m.nextPage=h,q.set(r,m),p()&&(f?.disconnect(),i.remove())}catch(d){for(const _ of u)_.remove();N(d)}finally{E=!1}},f=new IntersectionObserver(u=>{u.some(d=>d.isIntersecting)&&b()},{rootMargin:U});f.observe(i);let g=!1;const L=u=>{if(r!=="latest"||g)return;const d=u.detail?.ids;if(!Array.isArray(d)||d.length===0)return;const _=d.map(c=>Number(c)).filter(c=>Number.isFinite(c)&&c>0&&n.querySelector(`[data-post-id="${c}"]`)===null);_.length!==0&&(g=!0,Promise.all(_.slice(0,8).map(async c=>{try{const{data:m}=await S.get(`/api/v1/posts/${c}`);return m}catch{return null}})).then(c=>{const m=c.filter(s=>s!==null).sort((s,l)=>l.id-s.id).map(s=>{const l=P(s);return l.classList.add("is-new-post"),l});m.length>0&&(n.querySelector("[data-empty-state]")?.remove(),n.prepend(...m))}).finally(()=>{g=!1}))};return window.addEventListener("mofu:realtime-post",L),()=>{f.disconnect(),window.removeEventListener("mofu:realtime-post",L)}};export{F as init};
