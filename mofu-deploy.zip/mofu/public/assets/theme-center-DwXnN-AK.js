import{l as X,k as K,m as Z,o as Y,p as tt,q as et,S as st,u as nt,v as rt,a as G,w as V,x as W,y as ot,d as b,t as P,g as it,s as z,b as O,z as at,A as lt}from"./main-CNPx2KPJ.js";/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ht{fromInt(t){return X(t)}toInt(t){return K(t[0],t[1],t[2])}distance(t,e){const n=t[0]-e[0],r=t[1]-e[1],s=t[2]-e[2];return n*n+r*r+s*s}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ct=10,mt=3;class dt{static quantize(t,e,n){const r=new Map,s=new Array,m=new Array,a=new ht;let f=0;for(let i=0;i<t.length;i++){const c=t[i],y=r.get(c);y===void 0?(f++,s.push(a.fromInt(c)),m.push(c),r.set(c,1)):r.set(c,y+1)}const x=new Array;for(let i=0;i<f;i++){const c=m[i],y=r.get(c);y!==void 0&&(x[i]=y)}let l=Math.min(n,f);e.length>0&&(l=Math.min(l,e.length));const g=new Array;for(let i=0;i<e.length;i++)g.push(a.fromInt(e[i]));const v=l-g.length;if(e.length===0&&v>0)for(let i=0;i<v;i++){const c=Math.random()*100,y=Math.random()*201+-100,B=Math.random()*201+-100;g.push(new Array(c,y,B))}const d=new Array;for(let i=0;i<f;i++)d.push(Math.floor(Math.random()*l));const E=new Array;for(let i=0;i<l;i++){E.push(new Array);for(let c=0;c<l;c++)E[i].push(0)}const p=new Array;for(let i=0;i<l;i++){p.push(new Array);for(let c=0;c<l;c++)p[i].push(new gt)}const C=new Array;for(let i=0;i<l;i++)C.push(0);for(let i=0;i<ct;i++){for(let h=0;h<l;h++){for(let u=h+1;u<l;u++){const L=a.distance(g[h],g[u]);p[u][h].distance=L,p[u][h].index=h,p[h][u].distance=L,p[h][u].index=u}p[h].sort();for(let u=0;u<l;u++)E[h][u]=p[h][u].index}let c=0;for(let h=0;h<f;h++){const u=s[h],L=d[h],M=g[L],N=a.distance(u,M);let U=N,_=-1;for(let D=0;D<l;D++){if(p[L][D].distance>=4*N)continue;const F=a.distance(u,g[D]);F<U&&(U=F,_=D)}_!==-1&&Math.abs(Math.sqrt(U)-Math.sqrt(N))>mt&&(c++,d[h]=_)}if(c===0&&i!==0)break;const y=new Array(l).fill(0),B=new Array(l).fill(0),S=new Array(l).fill(0);for(let h=0;h<l;h++)C[h]=0;for(let h=0;h<f;h++){const u=d[h],L=s[h],M=x[h];C[u]+=M,y[u]+=L[0]*M,B[u]+=L[1]*M,S[u]+=L[2]*M}for(let h=0;h<l;h++){const u=C[h];if(u===0){g[h]=[0,0,0];continue}const L=y[h]/u,M=B[h]/u,N=S[h]/u;g[h]=[L,M,N]}}const A=new Map;for(let i=0;i<l;i++){const c=C[i];if(c===0)continue;const y=a.toInt(g[i]);A.has(y)||A.set(y,c)}return A}}class gt{constructor(){this.distance=-1,this.index=-1}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ut{static quantize(t){const e=new Map;for(let n=0;n<t.length;n++){const r=t[n];Z(r)<255||e.set(r,(e.get(r)??0)+1)}return e}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const j=5,k=33,q=35937,R={RED:"red",GREEN:"green",BLUE:"blue"};class ft{constructor(t=[],e=[],n=[],r=[],s=[],m=[]){this.weights=t,this.momentsR=e,this.momentsG=n,this.momentsB=r,this.moments=s,this.cubes=m}quantize(t,e){this.constructHistogram(t),this.computeMoments();const n=this.createBoxes(e);return this.createResult(n.resultCount)}constructHistogram(t){this.weights=Array.from({length:q}).fill(0),this.momentsR=Array.from({length:q}).fill(0),this.momentsG=Array.from({length:q}).fill(0),this.momentsB=Array.from({length:q}).fill(0),this.moments=Array.from({length:q}).fill(0);const e=ut.quantize(t);for(const[n,r]of e.entries()){const s=Y(n),m=tt(n),a=et(n),f=8-j,x=(s>>f)+1,l=(m>>f)+1,g=(a>>f)+1,v=this.getIndex(x,l,g);this.weights[v]=(this.weights[v]??0)+r,this.momentsR[v]+=r*s,this.momentsG[v]+=r*m,this.momentsB[v]+=r*a,this.moments[v]+=r*(s*s+m*m+a*a)}}computeMoments(){for(let t=1;t<k;t++){const e=Array.from({length:k}).fill(0),n=Array.from({length:k}).fill(0),r=Array.from({length:k}).fill(0),s=Array.from({length:k}).fill(0),m=Array.from({length:k}).fill(0);for(let a=1;a<k;a++){let f=0,x=0,l=0,g=0,v=0;for(let d=1;d<k;d++){const E=this.getIndex(t,a,d);f+=this.weights[E],x+=this.momentsR[E],l+=this.momentsG[E],g+=this.momentsB[E],v+=this.moments[E],e[d]+=f,n[d]+=x,r[d]+=l,s[d]+=g,m[d]+=v;const p=this.getIndex(t-1,a,d);this.weights[E]=this.weights[p]+e[d],this.momentsR[E]=this.momentsR[p]+n[d],this.momentsG[E]=this.momentsG[p]+r[d],this.momentsB[E]=this.momentsB[p]+s[d],this.moments[E]=this.moments[p]+m[d]}}}}createBoxes(t){this.cubes=Array.from({length:t}).fill(0).map(()=>new vt);const e=Array.from({length:t}).fill(0);this.cubes[0].r0=0,this.cubes[0].g0=0,this.cubes[0].b0=0,this.cubes[0].r1=k-1,this.cubes[0].g1=k-1,this.cubes[0].b1=k-1;let n=t,r=0;for(let s=1;s<t;s++){this.cut(this.cubes[r],this.cubes[s])?(e[r]=this.cubes[r].vol>1?this.variance(this.cubes[r]):0,e[s]=this.cubes[s].vol>1?this.variance(this.cubes[s]):0):(e[r]=0,s--),r=0;let m=e[0];for(let a=1;a<=s;a++)e[a]>m&&(m=e[a],r=a);if(m<=0){n=s+1;break}}return new xt(t,n)}createResult(t){const e=[];for(let n=0;n<t;++n){const r=this.cubes[n],s=this.volume(r,this.weights);if(s>0){const m=Math.round(this.volume(r,this.momentsR)/s),a=Math.round(this.volume(r,this.momentsG)/s),f=Math.round(this.volume(r,this.momentsB)/s),x=255<<24|(m&255)<<16|(a&255)<<8|f&255;e.push(x)}}return e}variance(t){const e=this.volume(t,this.momentsR),n=this.volume(t,this.momentsG),r=this.volume(t,this.momentsB),s=this.moments[this.getIndex(t.r1,t.g1,t.b1)]-this.moments[this.getIndex(t.r1,t.g1,t.b0)]-this.moments[this.getIndex(t.r1,t.g0,t.b1)]+this.moments[this.getIndex(t.r1,t.g0,t.b0)]-this.moments[this.getIndex(t.r0,t.g1,t.b1)]+this.moments[this.getIndex(t.r0,t.g1,t.b0)]+this.moments[this.getIndex(t.r0,t.g0,t.b1)]-this.moments[this.getIndex(t.r0,t.g0,t.b0)],m=e*e+n*n+r*r,a=this.volume(t,this.weights);return s-m/a}cut(t,e){const n=this.volume(t,this.momentsR),r=this.volume(t,this.momentsG),s=this.volume(t,this.momentsB),m=this.volume(t,this.weights),a=this.maximize(t,R.RED,t.r0+1,t.r1,n,r,s,m),f=this.maximize(t,R.GREEN,t.g0+1,t.g1,n,r,s,m),x=this.maximize(t,R.BLUE,t.b0+1,t.b1,n,r,s,m);let l;const g=a.maximum,v=f.maximum,d=x.maximum;if(g>=v&&g>=d){if(a.cutLocation<0)return!1;l=R.RED}else v>=g&&v>=d?l=R.GREEN:l=R.BLUE;switch(e.r1=t.r1,e.g1=t.g1,e.b1=t.b1,l){case R.RED:t.r1=a.cutLocation,e.r0=t.r1,e.g0=t.g0,e.b0=t.b0;break;case R.GREEN:t.g1=f.cutLocation,e.r0=t.r0,e.g0=t.g1,e.b0=t.b0;break;case R.BLUE:t.b1=x.cutLocation,e.r0=t.r0,e.g0=t.g0,e.b0=t.b1;break;default:throw new Error("unexpected direction "+l)}return t.vol=(t.r1-t.r0)*(t.g1-t.g0)*(t.b1-t.b0),e.vol=(e.r1-e.r0)*(e.g1-e.g0)*(e.b1-e.b0),!0}maximize(t,e,n,r,s,m,a,f){const x=this.bottom(t,e,this.momentsR),l=this.bottom(t,e,this.momentsG),g=this.bottom(t,e,this.momentsB),v=this.bottom(t,e,this.weights);let d=0,E=-1,p=0,C=0,A=0,i=0;for(let c=n;c<r;c++){if(p=x+this.top(t,e,c,this.momentsR),C=l+this.top(t,e,c,this.momentsG),A=g+this.top(t,e,c,this.momentsB),i=v+this.top(t,e,c,this.weights),i===0)continue;let y=(p*p+C*C+A*A)*1,B=i*1,S=y/B;p=s-p,C=m-C,A=a-A,i=f-i,i!==0&&(y=(p*p+C*C+A*A)*1,B=i*1,S+=y/B,S>d&&(d=S,E=c))}return new pt(E,d)}volume(t,e){return e[this.getIndex(t.r1,t.g1,t.b1)]-e[this.getIndex(t.r1,t.g1,t.b0)]-e[this.getIndex(t.r1,t.g0,t.b1)]+e[this.getIndex(t.r1,t.g0,t.b0)]-e[this.getIndex(t.r0,t.g1,t.b1)]+e[this.getIndex(t.r0,t.g1,t.b0)]+e[this.getIndex(t.r0,t.g0,t.b1)]-e[this.getIndex(t.r0,t.g0,t.b0)]}bottom(t,e,n){switch(e){case R.RED:return-n[this.getIndex(t.r0,t.g1,t.b1)]+n[this.getIndex(t.r0,t.g1,t.b0)]+n[this.getIndex(t.r0,t.g0,t.b1)]-n[this.getIndex(t.r0,t.g0,t.b0)];case R.GREEN:return-n[this.getIndex(t.r1,t.g0,t.b1)]+n[this.getIndex(t.r1,t.g0,t.b0)]+n[this.getIndex(t.r0,t.g0,t.b1)]-n[this.getIndex(t.r0,t.g0,t.b0)];case R.BLUE:return-n[this.getIndex(t.r1,t.g1,t.b0)]+n[this.getIndex(t.r1,t.g0,t.b0)]+n[this.getIndex(t.r0,t.g1,t.b0)]-n[this.getIndex(t.r0,t.g0,t.b0)];default:throw new Error("unexpected direction $direction")}}top(t,e,n,r){switch(e){case R.RED:return r[this.getIndex(n,t.g1,t.b1)]-r[this.getIndex(n,t.g1,t.b0)]-r[this.getIndex(n,t.g0,t.b1)]+r[this.getIndex(n,t.g0,t.b0)];case R.GREEN:return r[this.getIndex(t.r1,n,t.b1)]-r[this.getIndex(t.r1,n,t.b0)]-r[this.getIndex(t.r0,n,t.b1)]+r[this.getIndex(t.r0,n,t.b0)];case R.BLUE:return r[this.getIndex(t.r1,t.g1,n)]-r[this.getIndex(t.r1,t.g0,n)]-r[this.getIndex(t.r0,t.g1,n)]+r[this.getIndex(t.r0,t.g0,n)];default:throw new Error("unexpected direction $direction")}}getIndex(t,e,n){return(t<<j*2)+(t<<j+1)+t+(e<<j)+e+n}}class vt{constructor(t=0,e=0,n=0,r=0,s=0,m=0,a=0){this.r0=t,this.r1=e,this.g0=n,this.g1=r,this.b0=s,this.b1=m,this.vol=a}}class xt{constructor(t,e){this.requestedCount=t,this.resultCount=e}}class pt{constructor(t,e){this.cutLocation=t,this.maximum=e}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class It{static quantize(t,e){const r=new ft().quantize(t,e);return dt.quantize(t,r,e)}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function wt(o){const t=await new Promise((e,n)=>{const r=document.createElement("canvas"),s=r.getContext("2d");if(!s){n(new Error("Could not get canvas context"));return}const m=()=>{r.width=o.width,r.height=o.height,s.drawImage(o,0,0);let f=[0,0,o.width,o.height];const x=o.dataset.area;x&&/^\d+(\s*,\s*\d+){3}$/.test(x)&&(f=x.split(/\s*,\s*/).map(E=>parseInt(E,10)));const[l,g,v,d]=f;e(s.getImageData(l,g,v,d).data)},a=()=>{n(new Error("Image load failed"))};o.complete?m():(o.onload=m,o.onerror=a)});return Et(t)}function Et(o){const t=[];for(let s=0;s<o.length;s+=4){const m=o[s],a=o[s+1],f=o[s+2];if(o[s+3]<255)continue;const l=nt(m,a,f);t.push(l)}const e=It.quantize(t,128);return st.score(e)[0]}function yt(o){return new Promise((t,e)=>{const n=new Image;n.onload=()=>t(n),n.onerror=()=>e(new Error("图片加载失败")),n.src=o})}async function Ct(o){const t=URL.createObjectURL(o);try{const e=await yt(t),n=await wt(e);return rt(n).toUpperCase()}finally{URL.revokeObjectURL(t)}}const Rt={name:"默认主题",sourceColor:"#775A0D",scheme:"auto",contrast:"standard",variant:"tonalSpot",density:0,motion:"standard"};function Q(o){try{return(o.trim()===""?null:JSON.parse(o))??null}catch{return null}}function At(o){return{name:o.name,sourceColor:o.source_color,scheme:o.scheme==="light"||o.scheme==="dark"?o.scheme:"auto",contrast:o.contrast==="medium"||o.contrast==="high"?o.contrast:"standard",variant:o.variant,density:Number(o.density??0),motion:o.motion==="expressive"?"expressive":"standard",isCustom:!0}}const Bt=()=>{const o=G("[data-theme-center]");if(o===null)return;const t=window.__MOFU__?.user??null,e=Q(o.dataset.defaultTheme??"")??Rt,n=Q(o.dataset.activeTheme??""),r=n!==null?At(n):{...e};let s=V(r),m=null;const a=G("[data-theme-color-input]",o),f=G("[data-theme-color-value]",o),x=G("[data-theme-variant]",o),l=G("[data-theme-scheme]",o),g=G("[data-theme-contrast]",o),v=G("[data-theme-density]",o),d=G("[data-theme-motion]",o),E=G("[data-theme-name]",o),p=G("[data-theme-preview-name]"),C=G("[data-theme-wallpaper-input]",o),A=I=>{p!==null&&(p.textContent=I===""?"未命名主题":I)},i=()=>{a!==null&&(a.value=s.sourceColor),f!==null&&(f.textContent=s.sourceColor),x!==null&&(x.value=s.variant),l!==null&&(l.value=s.scheme),g!==null&&(g.value=s.contrast),v!==null&&(v.value=String(s.density)),d!==null&&(d.value=s.motion)},c=()=>{m=W(s),ot(s,m),i()};i(),c();const y=I=>{s={...s,sourceColor:I},c()},B=()=>{a!==null&&y(a.value.toUpperCase())},S=I=>{const w=I.target.closest("[data-color]");w!==null&&y((w.dataset.color??"").toUpperCase())},h=()=>{x!==null&&(s={...s,variant:x.value},c())},u=()=>{l!==null&&(s={...s,scheme:l.value},c())},L=()=>{g!==null&&(s={...s,contrast:g.value},c())},M=()=>{v!==null&&(s={...s,density:Number(v.value)},c())},N=()=>{d!==null&&(s={...s,motion:d.value==="expressive"?"expressive":"standard"},c())},U=async()=>{const I=C?.files?.[0];if(I!==void 0)try{const w=await Ct(I);y(w),b(`已从图片提取主题色 ${w}`,"success")}catch(w){P(w)}finally{C!==null&&(C.value="")}},_=async I=>{const w=(E?.value??"").trim()||"我的主题",T=m??W(s);try{if(t===null){lt(s,T),A(w),b("已应用到本机（登录后可跨设备同步）","success");return}z(I,!0),await O.post("/api/v1/themes",{name:w,source_color:s.sourceColor,scheme:s.scheme,contrast:s.contrast,variant:s.variant,density:s.density,motion:s.motion,css_vars:T}),b("主题已保存并应用","success"),window.location.assign("/settings/appearance?ok=1")}catch(J){z(I,!1),P(J)}},D=()=>{t===null&&at(),s=V({...e}),A("默认主题"),c(),b("已恢复默认主题（点击保存后生效）","info")},F=async(I,w)=>{if(!(I<=0)){z(w,!0);try{await O.post(`/api/v1/themes/${I}/activate`),window.location.assign("/settings/appearance?ok=1")}catch(T){z(w,!1),P(T)}}},H=async(I,w)=>{if(!(I<=0)&&await it("确定删除这套主题吗？",{danger:!0,confirmLabel:"删除"})){z(w,!0);try{await O.delete(`/api/v1/themes/${I}`),window.location.assign("/settings/appearance?ok=1")}catch(T){z(w,!1),P(T)}}},$=I=>{const w=I.target.closest("[data-action]");if(w!==null)switch(w.dataset.action){case"save-theme":I.preventDefault(),_(w);break;case"reset-theme":I.preventDefault(),D();break;case"activate-theme":I.preventDefault(),F(Number(w.dataset.themeId??0),w);break;case"delete-theme":I.preventDefault(),H(Number(w.dataset.themeId??0),w);break}};return o.addEventListener("click",$),o.addEventListener("click",S),a?.addEventListener("input",B),x?.addEventListener("change",h),l?.addEventListener("change",u),g?.addEventListener("change",L),v?.addEventListener("change",M),d?.addEventListener("change",N),C?.addEventListener("change",()=>void U()),()=>{o.removeEventListener("click",$),o.removeEventListener("click",S),a?.removeEventListener("input",B),x?.removeEventListener("change",h),l?.removeEventListener("change",u),g?.removeEventListener("change",L),v?.removeEventListener("change",M),d?.removeEventListener("change",N)}};export{Bt as init};
